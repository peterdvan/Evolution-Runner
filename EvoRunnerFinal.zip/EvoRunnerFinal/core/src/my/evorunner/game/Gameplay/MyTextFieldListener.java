package my.evorunner.game.Gameplay;

import com.badlogic.gdx.scenes.scene2d.ui.TextField;
import com.badlogic.gdx.scenes.scene2d.ui.TextField.TextFieldListener;

public class MyTextFieldListener implements TextFieldListener {
    @Override
    public void keyTyped(TextField textField, char c) {
        textField.setText(textField.getText() + c);
    }
}
