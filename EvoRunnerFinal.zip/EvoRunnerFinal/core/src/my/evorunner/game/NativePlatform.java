package my.evorunner.game;

public interface NativePlatform {
    public void displayError(String errorMessage);
}
