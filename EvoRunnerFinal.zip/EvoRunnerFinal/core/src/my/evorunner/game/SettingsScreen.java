package my.evorunner.game;

/**
 * Settings screen
 *
 * Version 1.0
 * Last Edited: Matthew Phan
 * Changelog 1.0
 */

public class SettingsScreen  {

}
