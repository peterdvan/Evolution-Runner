package my.evorunner.game;

/**
 * Created by Peter on 1/21/2018.
 */

public interface AdHandler {
    public void showAds(boolean show);
    public int getBannerHeight();
}
